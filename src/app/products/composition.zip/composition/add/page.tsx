'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Save, Plus, Trash2, Loader2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext'; // Import useAuth
import { Switch } from '@/components/ui/switch'; // Import Switch

// Interface untuk material yang dipilih dalam komposisi
interface CompositionMaterial {
  id: string;
  materialId: string;
  materialName: string;
  quantity: string;
  unit: string;
}

// Interface untuk data produk
interface Product {
  id: string;
  name: string;
}

// Interface untuk data material
interface Material {
  id: string;
  name: string;
  unit: string;
  basePrice?: number; // Harga dasar material
}

// Interface untuk data komposisi baru
interface NewCompositionData {
  productId: string;
  materials: CompositionMaterial[];
  isTemplate: boolean;
  templateName: string;
}

export default function AddCompositionPage() {
  const router = useRouter();
  const { tenantId } = useAuth(); // Get tenantId from context
  const [products, setProducts] = useState<Product[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [totalEstimatedPrice, setTotalEstimatedPrice] = useState<number>(0);
  const [isLoadingProducts, setIsLoadingProducts] = useState(false);
  const [isLoadingMaterials, setIsLoadingMaterials] = useState(false);
  
  const [formData, setFormData] = useState<NewCompositionData>({
    productId: '',
    materials: [],
    isTemplate: true, // Default: Menjadi template
    templateName: '',
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{
    productId?: string;
    materials?: string;
    templateName?: string; // Add templateName error
    general?: string;
  }>({});

  // Fetch products data
  useEffect(() => {
    const fetchProducts = async () => {
      if (!tenantId) return; // Don't fetch if tenantId is not available
      setIsLoadingProducts(true);
      try {
        const response = await fetch('/api/products', {
          headers: {
            'X-Tenant-Id': tenantId,
          },
        });
        if (!response.ok) throw new Error('Gagal mengambil data produk');
        const data = await response.json();
        
        // Format data produk untuk dropdown
        const formattedProducts = data.map((product: any) => ({
          id: product.id,
          name: product.name
        }));
        
        setProducts(formattedProducts);
      } catch (error) {
        console.error('Error fetching products:', error);
        toast.error('Gagal mengambil data produk');
      } finally {
        setIsLoadingProducts(false);
      }
    };

    fetchProducts();
  }, [tenantId]); // Add tenantId dependency

  // Fetch materials data
  useEffect(() => {
    const fetchMaterials = async () => {
      if (!tenantId) return; // Don't fetch if tenantId is not available
      setIsLoadingMaterials(true);
      try {
        const response = await fetch('/api/products/materials', {
          headers: {
            'X-Tenant-Id': tenantId,
          },
        });
        if (!response.ok) throw new Error('Gagal mengambil data material');
        const data = await response.json();
        
        console.log('Material data received:', data); // Tambahkan log untuk debugging
        
        // Format data material untuk dropdown dengan harga dasar
        const formattedMaterials = data.data.map((material: any) => ({
          id: material.id,
          name: material.name,
          unit: material.unit,
          basePrice: material.basePrice || 0 // Tambahkan harga dasar
        }));
        
        console.log('Formatted materials:', formattedMaterials); // Tambahkan log untuk debugging
        
        setMaterials(formattedMaterials);
      } catch (error) {
        console.error('Error fetching materials:', error);
        toast.error('Gagal mengambil data material');
      } finally {
        setIsLoadingMaterials(false);
      }
    };

    fetchMaterials();
  }, [tenantId]); // Add tenantId dependency

  const validateForm = (): boolean => {
    const newErrors: {
      productId?: string;
      materials?: string;
      templateName?: string;
      general?: string;
    } = {};

    // Validasi productId hanya jika tidak menjadi template
    if (!formData.isTemplate && !formData.productId) {
      newErrors.productId = 'Produk harus dipilih.';
    }
    
    // Validasi nama template jika menjadi template
    if (formData.isTemplate && !formData.templateName.trim()) {
      newErrors.templateName = 'Nama template harus diisi.';
    }

    if (formData.materials.length === 0) {
      newErrors.materials = 'Minimal satu material harus ditambahkan.';
    } else {
      // Validasi setiap material
      const invalidMaterial = formData.materials.find(
        (material) => !material.materialId || !material.quantity || parseFloat(material.quantity) <= 0
      );
      
      if (invalidMaterial) {
        newErrors.materials = 'Semua material harus memiliki nama dan jumlah yang valid.';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleProductChange = (value: string) => {
    setFormData((prev) => ({ ...prev, productId: value }));
    if (errors.productId) {
      setErrors((prev) => ({ ...prev, productId: undefined }));
    }
  };

  const addMaterial = () => {
    const newMaterial: CompositionMaterial = {
      id: Date.now().toString(), // Temporary ID for UI
      materialId: '',
      materialName: '',
      quantity: '',
      unit: '',
    };

    setFormData((prev) => ({
      ...prev,
      materials: [...prev.materials, newMaterial],
    }));

    if (errors.materials) {
      setErrors((prev) => ({ ...prev, materials: undefined }));
    }
  };

  const removeMaterial = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      materials: prev.materials.filter((material) => material.id !== id),
    }));
  };

  // Fungsi untuk menghitung total estimasi harga
  const calculateTotalEstimatedPrice = (compositionMaterials: CompositionMaterial[], materialsList: Material[]) => {
    let total = 0;
    
    compositionMaterials.forEach(material => {
      const materialData = materialsList.find(m => m.id === material.materialId);
      if (materialData?.basePrice && material.quantity) {
        total += materialData.basePrice * parseFloat(material.quantity);
      }
    });
    
    return total;
  };
  
  // Update total estimasi harga setiap kali material berubah
  useEffect(() => {
    const total = formData.materials.reduce((sum, material) => {
      const materialData = materials.find(m => m.id === material.materialId);
      if (materialData?.basePrice && material.quantity) {
        return sum + (materialData.basePrice * parseFloat(material.quantity));
      }
      return sum;
    }, 0);
    
    setTotalEstimatedPrice(total);
  }, [formData.materials, materials]);

  const handleMaterialChange = (id: string, field: keyof CompositionMaterial, value: string) => {
    setFormData((prev) => ({
      ...prev,
      materials: prev.materials.map((material) => {
        if (material.id === id) {
          if (field === 'materialId') {
            // Jika materialId berubah, update juga materialName dan unit
            const selectedMaterial = materials.find((m) => m.id === value);
            return {
              ...material,
              materialId: value,
              materialName: selectedMaterial?.name || '',
              unit: selectedMaterial?.unit || '',
            };
          }
          return { ...material, [field]: value };
        }
        return material;
      }),
    }));

    if (errors.materials) {
      setErrors((prev) => ({ ...prev, materials: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!validateForm() || !tenantId) {
      toast.error('Harap periksa kembali data yang Anda masukkan.');
      if (!tenantId) {
        setErrors((prev) => ({ ...prev, general: 'Tenant ID tidak ditemukan. Silakan login ulang.' }));
      }
      return;
    }

    setIsLoading(true);
    setErrors({}); // Clear previous errors

    // Prepare data for API
    const payload = {
      productId: formData.isTemplate ? null : formData.productId,
      isTemplate: formData.isTemplate,
      templateName: formData.isTemplate ? formData.templateName : null,
      materials: formData.materials.map(m => ({
        materialId: m.materialId,
        quantity: parseFloat(m.quantity) // Convert quantity to number
      })),
    };

    try {
      const response = await fetch('/api/products/composition', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Tenant-Id': tenantId, // Add tenantId header
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('API Error:', errorData);
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log('Komposisi berhasil dibuat:', result);
      toast.success('Komposisi produk berhasil ditambahkan!');
      router.push('/products/composition'); // Redirect on success

    } catch (error) {
      console.error('Gagal mengirim data komposisi:', error);
      let errorMessage = 'Gagal menambahkan komposisi produk. Silakan coba lagi.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      setErrors((prev) => ({ ...prev, general: errorMessage }));
      toast.error(`Error: ${errorMessage}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-7 w-7"
                onClick={() => router.back()}
                type="button"
              >
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Kembali</span>
              </Button>
              <div>
                <CardTitle>Tambah Komposisi Produk</CardTitle>
                <CardDescription>
                  Buat komposisi material baru untuk produk atau sebagai template.
                </CardDescription>
              </div>
            </div>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Simpan Komposisi
            </Button>
          </CardHeader>
          <CardContent className="grid gap-6">
            {errors.general && (
              <div className="text-red-600 text-sm font-medium p-3 bg-red-100 border border-red-300 rounded-md">
                {errors.general}
              </div>
            )}
            
            <div className="grid gap-3">
              <Label htmlFor="isTemplate">Jadikan Template?</Label>
              <div className="flex items-center space-x-2">
                <Switch
                  id="isTemplate"
                  checked={formData.isTemplate}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, isTemplate: checked }))}
                />
                <span className="text-sm text-muted-foreground">
                  {formData.isTemplate ? 'Komposisi ini akan disimpan sebagai template.' : 'Komposisi ini akan langsung dikaitkan dengan produk.'}
                </span>
              </div>
            </div>

            {formData.isTemplate ? (
              <div className="grid gap-3">
                <Label htmlFor="templateName">Nama Template</Label>
                <Input
                  id="templateName"
                  value={formData.templateName}
                  onChange={(e) => {
                    setFormData((prev) => ({ ...prev, templateName: e.target.value }));
                    if (errors.templateName) {
                      setErrors((prev) => ({ ...prev, templateName: undefined }));
                    }
                  }}
                  placeholder="Masukkan nama template (e.g., Komposisi Meja Standar)"
                />
                {errors.templateName && <p className="text-xs text-red-600">{errors.templateName}</p>}
              </div>
            ) : (
              <div className="grid gap-3">
                <Label htmlFor="product">Pilih Produk</Label>
                <Select
                  value={formData.productId}
                  onValueChange={handleProductChange}
                  disabled={isLoadingProducts}
                >
                  <SelectTrigger id="product" aria-label="Pilih Produk">
                    <SelectValue placeholder={isLoadingProducts ? "Memuat produk..." : "Pilih produk yang akan dibuat komposisinya"} />
                  </SelectTrigger>
                  <SelectContent>
                    {products.length > 0 ? (
                      products.map((product) => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name}
                        </SelectItem>
                      ))
                    ) : (
                      // Remove the invalid SelectItem with value=""
                      <div className="px-2 py-1.5 text-sm text-muted-foreground">
                        {isLoadingProducts ? "Memuat..." : "Tidak ada produk tersedia"}
                      </div>
                    )}
                  </SelectContent>
                </Select>
                {errors.productId && <p className="text-xs text-red-600">{errors.productId}</p>}
              </div>
            )}

            <div className="grid gap-4">
              <Label>Material yang Dibutuhkan</Label>
              {formData.materials.map((material, index) => (
                <div key={material.id} className="grid grid-cols-1 md:grid-cols-[2fr_1fr_auto] gap-3 items-end border p-4 rounded-md relative">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-1 right-1 h-6 w-6 text-red-500 hover:bg-red-100"
                    onClick={() => removeMaterial(material.id)}
                    type="button"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <div className="grid gap-1.5">
                    <Label htmlFor={`material-${material.id}`}>Material</Label>
                    <Select
                      value={material.materialId}
                      onValueChange={(value) => handleMaterialChange(material.id, 'materialId', value)}
                      disabled={isLoadingMaterials}
                    >
                      <SelectTrigger id={`material-${material.id}`} aria-label="Pilih Material">
                        <SelectValue placeholder={isLoadingMaterials ? "Memuat material..." : "Pilih material"} />
                      </SelectTrigger>
                      <SelectContent>
                        {materials.length > 0 ? (
                          materials.map((mat) => (
                            <SelectItem key={mat.id} value={mat.id}>
                              {mat.name} ({mat.unit})
                            </SelectItem>
                          ))
                        ) : (
                          // Remove the invalid SelectItem with value=""
                          <div className="px-2 py-1.5 text-sm text-muted-foreground">
                            {isLoadingMaterials ? "Memuat..." : "Tidak ada material tersedia"}
                          </div>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label htmlFor={`quantity-${material.id}`}>Jumlah</Label>
                    <Input
                      id={`quantity-${material.id}`}
                      type="number"
                      placeholder="Jumlah"
                      value={material.quantity}
                      onChange={(e) => handleMaterialChange(material.id, 'quantity', e.target.value)}
                      min="0.01" // Allow decimals
                      step="0.01"
                    />
                  </div>
                  <div className="text-sm text-muted-foreground pt-7">
                    {material.unit || 'Unit'}
                  </div>
                </div>
              ))}
              <Button type="button" variant="outline" onClick={addMaterial} className="mt-2">
                <Plus className="mr-2 h-4 w-4" /> Tambah Material
              </Button>
              {errors.materials && <p className="text-xs text-red-600 mt-1">{errors.materials}</p>}
            </div>

            {/* Display Total Estimated Price */}
            <div className="grid gap-3 mt-4 border-t pt-4">
              <Label className="font-semibold">Total Estimasi Harga Modal</Label>
              <p className="text-lg font-bold">
                {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalEstimatedPrice)}
              </p>
              <p className="text-xs text-muted-foreground">
                Estimasi ini dihitung berdasarkan harga dasar material yang terdaftar. Harga aktual dapat bervariasi.
              </p>
            </div>
          </CardContent>
          <CardFooter className="border-t px-6 py-4">
            <Button type="submit" disabled={isLoading} className="ml-auto">
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Simpan Komposisi
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  );
}